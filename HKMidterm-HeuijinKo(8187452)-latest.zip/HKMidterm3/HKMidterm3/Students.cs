﻿/*
 * Midterm
 * Prof. Harry Scanlan
 * Heuijin Ko(8187452)
 * Question #3
 **/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HKMidterm3
{
    class Students
    {
        public string LastName { set; get; }
        public string ID { set; get; }
        public double Mark { set; get; }

    }
}
